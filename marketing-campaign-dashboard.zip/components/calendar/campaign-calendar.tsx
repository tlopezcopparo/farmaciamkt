'use client'

import { useState, useMemo } from 'react'
import Link from 'next/link'
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  addDays,
  addMonths,
  subMonths,
  isSameMonth,
  isSameDay,
  isWithinInterval,
} from 'date-fns'
import { es } from 'date-fns/locale'
import type { Campaign, CampaignType } from '@/lib/types'
import { CAMPAIGN_TYPE_LABELS, CAMPAIGN_STATUS_LABELS } from '@/lib/types'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

interface CampaignCalendarProps {
  campaigns: Campaign[]
}

const typeColors: Record<CampaignType, string> = {
  descuento: 'bg-blue-500',
  promocion: 'bg-purple-500',
  lanzamiento: 'bg-emerald-500',
  fidelizacion: 'bg-rose-500',
}

const typeBorderColors: Record<CampaignType, string> = {
  descuento: 'border-l-blue-500',
  promocion: 'border-l-purple-500',
  lanzamiento: 'border-l-emerald-500',
  fidelizacion: 'border-l-rose-500',
}

export function CampaignCalendar({ campaigns }: CampaignCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)

  const monthStart = startOfMonth(currentDate)
  const monthEnd = endOfMonth(monthStart)
  const startDate = startOfWeek(monthStart, { weekStartsOn: 1 })
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 })

  // Generate calendar days
  const calendarDays = useMemo(() => {
    const days: Date[] = []
    let day = startDate
    while (day <= endDate) {
      days.push(day)
      day = addDays(day, 1)
    }
    return days
  }, [startDate, endDate])

  // Get campaigns for a specific day
  const getCampaignsForDay = (date: Date) => {
    return campaigns.filter((campaign) => {
      const start = new Date(campaign.startDate)
      const end = new Date(campaign.endDate)
      return isWithinInterval(date, { start, end })
    })
  }

  // Get campaigns for selected date
  const selectedDateCampaigns = selectedDate ? getCampaignsForDay(selectedDate) : []

  const goToPreviousMonth = () => setCurrentDate(subMonths(currentDate, 1))
  const goToNextMonth = () => setCurrentDate(addMonths(currentDate, 1))
  const goToToday = () => {
    setCurrentDate(new Date())
    setSelectedDate(new Date())
  }

  const weekDays = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_350px]">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div>
            <CardTitle className="capitalize">
              {format(currentDate, 'MMMM yyyy', { locale: es })}
            </CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={goToToday}>
              Hoy
            </Button>
            <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={goToNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Week day headers */}
          <div className="grid grid-cols-7 mb-2">
            {weekDays.map((day) => (
              <div
                key={day}
                className="text-center text-sm font-medium text-muted-foreground py-2"
              >
                {day}
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-px bg-muted rounded-lg overflow-hidden">
            {calendarDays.map((day, index) => {
              const dayCampaigns = getCampaignsForDay(day)
              const isCurrentMonth = isSameMonth(day, currentDate)
              const isToday = isSameDay(day, new Date())
              const isSelected = selectedDate && isSameDay(day, selectedDate)

              return (
                <button
                  key={index}
                  onClick={() => setSelectedDate(day)}
                  className={cn(
                    'min-h-[80px] p-2 bg-card text-left transition-colors hover:bg-muted/50',
                    !isCurrentMonth && 'text-muted-foreground bg-muted/30',
                    isSelected && 'ring-2 ring-primary ring-inset',
                    isToday && 'bg-primary/5'
                  )}
                >
                  <div
                    className={cn(
                      'text-sm font-medium mb-1',
                      isToday &&
                        'bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center'
                    )}
                  >
                    {format(day, 'd')}
                  </div>
                  <div className="space-y-1">
                    {dayCampaigns.slice(0, 2).map((campaign) => (
                      <div
                        key={campaign.id}
                        className={cn(
                          'text-xs truncate rounded px-1 py-0.5 text-white',
                          typeColors[campaign.type]
                        )}
                        title={campaign.name}
                      >
                        {campaign.name}
                      </div>
                    ))}
                    {dayCampaigns.length > 2 && (
                      <div className="text-xs text-muted-foreground">
                        +{dayCampaigns.length - 2} más
                      </div>
                    )}
                  </div>
                </button>
              )
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-4 mt-4 pt-4 border-t">
            {Object.entries(CAMPAIGN_TYPE_LABELS).map(([type, label]) => (
              <div key={type} className="flex items-center gap-2 text-sm">
                <div
                  className={cn('w-3 h-3 rounded', typeColors[type as CampaignType])}
                />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Selected day detail */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            {selectedDate
              ? format(selectedDate, "d 'de' MMMM", { locale: es })
              : 'Selecciona un día'}
          </CardTitle>
          <CardDescription>
            {selectedDate
              ? selectedDateCampaigns.length > 0
                ? `${selectedDateCampaigns.length} campaña(s) activa(s)`
                : 'Sin campañas para este día'
              : 'Haz clic en un día para ver detalles'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {selectedDate && selectedDateCampaigns.length > 0 ? (
            <div className="space-y-3">
              {selectedDateCampaigns.map((campaign) => (
                <Link
                  key={campaign.id}
                  href={`/campanas/${campaign.id}`}
                  className={cn(
                    'block rounded-lg border-l-4 p-3 hover:bg-muted/50 transition-colors',
                    typeBorderColors[campaign.type]
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1 min-w-0">
                      <p className="font-medium truncate">{campaign.name}</p>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {CAMPAIGN_TYPE_LABELS[campaign.type]}
                        </Badge>
                        <Badge
                          variant="secondary"
                          className={cn(
                            'text-xs',
                            campaign.status === 'activa' &&
                              'bg-green-100 text-green-700'
                          )}
                        >
                          {CAMPAIGN_STATUS_LABELS[campaign.status]}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                    {campaign.description}
                  </p>
                </Link>
              ))}
            </div>
          ) : selectedDate ? (
            <div className="text-center py-8 text-muted-foreground">
              <CalendarIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No hay campañas activas para este día</p>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <CalendarIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Selecciona un día en el calendario</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
