import Link from 'next/link'
import { CampaignForm } from '@/components/campaigns/campaign-form'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'

export default function NuevaCampanaPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/campanas">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Nueva Campaña</h1>
          <p className="text-muted-foreground">
            Crea una nueva campaña de marketing para tu red de farmacias.
          </p>
        </div>
      </div>

      <CampaignForm mode="create" />
    </div>
  )
}
