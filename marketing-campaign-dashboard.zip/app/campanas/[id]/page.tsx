import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getCampaignById, getProductsByIds, formatDate } from '@/lib/mock-data'
import { CAMPAIGN_TYPE_LABELS, CAMPAIGN_STATUS_LABELS, PHARMACY_CATEGORY_LABELS } from '@/lib/types'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { ArrowLeft, Pencil, Calendar, Building2, Package, TrendingUp } from 'lucide-react'

interface CampaignDetailPageProps {
  params: Promise<{ id: string }>
}

export default async function CampaignDetailPage({ params }: CampaignDetailPageProps) {
  const { id } = await params
  const campaign = getCampaignById(id)

  if (!campaign) {
    notFound()
  }

  const products = getProductsByIds(campaign.products)

  const getStatusBadgeClass = () => {
    switch (campaign.status) {
      case 'activa':
        return 'bg-green-100 text-green-700'
      case 'borrador':
        return 'bg-amber-100 text-amber-700'
      case 'finalizada':
        return ''
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/campanas">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight">{campaign.name}</h1>
            <Badge className={getStatusBadgeClass()}>
              {CAMPAIGN_STATUS_LABELS[campaign.status]}
            </Badge>
          </div>
          <p className="text-muted-foreground">{campaign.description}</p>
        </div>
        <Button asChild>
          <Link href={`/campanas/${id}/editar`}>
            <Pencil className="h-4 w-4 mr-2" />
            Editar
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tipo</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge variant="outline">{CAMPAIGN_TYPE_LABELS[campaign.type]}</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Período</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm">
              <div>{formatDate(campaign.startDate)}</div>
              <div className="text-muted-foreground">al {formatDate(campaign.endDate)}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alcance</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{campaign.reach}</div>
            <p className="text-xs text-muted-foreground">farmacias</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Participación</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{campaign.participation}%</div>
            <div className="mt-2 h-2 w-full bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full"
                style={{ width: `${campaign.participation}%` }}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Productos Incluidos
            </CardTitle>
            <CardDescription>
              {products.length > 0
                ? `${products.length} producto(s) en esta campaña`
                : 'No hay productos asociados a esta campaña'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {products.length > 0 ? (
              <div className="space-y-3">
                {products.map((product) => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between rounded-lg border p-3"
                  >
                    <div>
                      <div className="font-medium">{product.name}</div>
                      <div className="text-sm text-muted-foreground">{product.laboratory}</div>
                    </div>
                    <Badge variant="outline">{product.sku}</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                Esta campaña no tiene productos asociados
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Segmentación de Farmacias
            </CardTitle>
            <CardDescription>Criterios de segmentación para esta campaña</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="text-sm font-medium mb-2">Provincias</div>
              {campaign.pharmacySegment.provinces.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {campaign.pharmacySegment.provinces.map((province) => (
                    <Badge key={province} variant="secondary">
                      {province}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Todas las provincias</p>
              )}
            </div>
            <Separator />
            <div>
              <div className="text-sm font-medium mb-2">Categorías</div>
              {campaign.pharmacySegment.categories.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {campaign.pharmacySegment.categories.map((category) => (
                    <Badge key={category} variant="secondary">
                      Categoría {category}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Todas las categorías</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
