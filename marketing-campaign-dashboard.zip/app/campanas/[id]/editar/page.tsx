import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getCampaignById } from '@/lib/mock-data'
import { CampaignForm } from '@/components/campaigns/campaign-form'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'

interface EditCampanaPageProps {
  params: Promise<{ id: string }>
}

export default async function EditCampanaPage({ params }: EditCampanaPageProps) {
  const { id } = await params
  const campaign = getCampaignById(id)

  if (!campaign) {
    notFound()
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href={`/campanas/${id}`}>
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Editar Campaña</h1>
          <p className="text-muted-foreground">{campaign.name}</p>
        </div>
      </div>

      <CampaignForm campaign={campaign} mode="edit" />
    </div>
  )
}
