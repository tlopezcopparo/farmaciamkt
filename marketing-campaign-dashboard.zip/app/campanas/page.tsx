'use client'

import { useState } from 'react'
import { mockCampaigns } from '@/lib/mock-data'
import type { CampaignFilters } from '@/lib/types'
import { CampaignTable } from '@/components/campaigns/campaign-table'
import { CampaignFiltersBar } from '@/components/campaigns/campaign-filters'

export default function CampanasPage() {
  const [filters, setFilters] = useState<CampaignFilters>({})

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Campañas</h1>
        <p className="text-muted-foreground">
          Gestiona las campañas de marketing para tu red de farmacias.
        </p>
      </div>

      <CampaignFiltersBar filters={filters} onFiltersChange={setFilters} />

      <CampaignTable campaigns={mockCampaigns} filters={filters} />
    </div>
  )
}
