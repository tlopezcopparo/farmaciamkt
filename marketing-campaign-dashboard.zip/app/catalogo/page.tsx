'use client'

import { useState } from 'react'
import { mockProducts, getUniqueLaboratories } from '@/lib/mock-data'
import type { ProductFilters } from '@/lib/types'
import { ProductGrid } from '@/components/products/product-grid'
import { ProductFiltersBar } from '@/components/products/product-filters'

export default function CatalogoPage() {
  const [filters, setFilters] = useState<ProductFilters>({})
  const laboratories = getUniqueLaboratories()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Catálogo de Productos</h1>
        <p className="text-muted-foreground">
          Gestiona los productos disponibles para tus campañas de marketing.
        </p>
      </div>

      <ProductFiltersBar
        filters={filters}
        onFiltersChange={setFilters}
        laboratories={laboratories}
      />

      <ProductGrid products={mockProducts} filters={filters} />
    </div>
  )
}
