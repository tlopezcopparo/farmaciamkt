import { KPICards } from '@/components/dashboard/kpi-cards'
import { CampaignChart } from '@/components/dashboard/campaign-chart'
import { UpcomingCampaigns } from '@/components/dashboard/upcoming-campaigns'
import { RecentActivity } from '@/components/dashboard/recent-activity'
import {
  mockCampaigns,
  mockPharmacies,
  mockProducts,
  mockActivity,
  getActiveCampaigns,
  getUpcomingCampaigns,
} from '@/lib/mock-data'

export default function DashboardPage() {
  const activeCampaigns = getActiveCampaigns()
  const upcomingCampaigns = getUpcomingCampaigns(5)
  const activePharmacies = mockPharmacies.filter((p) => p.status === 'activa').length

  // Calculate average participation for active campaigns
  const avgParticipation =
    activeCampaigns.length > 0
      ? Math.round(
          activeCampaigns.reduce((sum, c) => sum + c.participation, 0) /
            activeCampaigns.length
        )
      : 0

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Resumen de la actividad de marketing de tu red de farmacias.
        </p>
      </div>

      <KPICards
        activeCampaigns={activeCampaigns.length}
        totalPharmacies={mockPharmacies.length}
        activePharmacies={activePharmacies}
        totalProducts={mockProducts.length}
        avgParticipation={avgParticipation}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <CampaignChart campaigns={mockCampaigns} />
        <div className="space-y-6">
          <UpcomingCampaigns campaigns={upcomingCampaigns} />
          <RecentActivity activities={mockActivity} />
        </div>
      </div>
    </div>
  )
}
