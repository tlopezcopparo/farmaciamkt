'use client'

import { useState } from 'react'
import { mockPharmacies, getUniqueProvinces } from '@/lib/mock-data'
import type { PharmacyFilters, Pharmacy } from '@/lib/types'
import { PharmacyTable } from '@/components/pharmacies/pharmacy-table'
import { PharmacyFiltersBar } from '@/components/pharmacies/pharmacy-filters'
import { toast } from 'sonner'

function exportToCSV(pharmacies: Pharmacy[], filters: PharmacyFilters) {
  // Filter pharmacies based on current filters
  const filteredPharmacies = pharmacies.filter((pharmacy) => {
    if (filters.province && pharmacy.province !== filters.province) return false
    if (filters.category && pharmacy.category !== filters.category) return false
    if (filters.status && pharmacy.status !== filters.status) return false
    if (
      filters.search &&
      !pharmacy.name.toLowerCase().includes(filters.search.toLowerCase()) &&
      !pharmacy.city.toLowerCase().includes(filters.search.toLowerCase())
    )
      return false
    return true
  })

  const headers = ['Nombre', 'Dirección', 'Ciudad', 'Provincia', 'Categoría', 'Contacto', 'Teléfono', 'Email', 'Estado', 'Volumen Mensual']
  const rows = filteredPharmacies.map((p) => [
    p.name,
    p.address,
    p.city,
    p.province,
    `Categoría ${p.category}`,
    p.contactName,
    p.contactPhone,
    p.contactEmail,
    p.status === 'activa' ? 'Activa' : 'Inactiva',
    p.monthlyVolume.toString(),
  ])

  const csvContent = [
    headers.join(','),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
  ].join('\n')

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `farmacias_${new Date().toISOString().split('T')[0]}.csv`
  link.click()
  URL.revokeObjectURL(link.href)
}

export default function FarmaciasPage() {
  const [filters, setFilters] = useState<PharmacyFilters>({})
  const provinces = getUniqueProvinces()

  const handleExport = () => {
    exportToCSV(mockPharmacies, filters)
    toast.success('Archivo CSV exportado correctamente')
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Red de Farmacias</h1>
        <p className="text-muted-foreground">
          Administra las farmacias de tu red y visualiza su información de contacto.
        </p>
      </div>

      <PharmacyFiltersBar
        filters={filters}
        onFiltersChange={setFilters}
        provinces={provinces}
        onExport={handleExport}
      />

      <PharmacyTable pharmacies={mockPharmacies} filters={filters} />
    </div>
  )
}
